require("model2")

function Init()
M2Eouttimer = 30
end

function Frame()
	local state = I960_ReadByte(0x202098);		-- 2= Attract, 3= Game Setup?, 
	local state2 = I960_ReadByte(0x20209C);		-- 2= Dont do drugs,4 or 6= sega rally logo, 3=attract beginner track,5= attract intermediate track,7= attract hard track,
	local state3 = I960_ReadByte(0x2020AC);		-- 1= select car, 5= MP game, 3= SP game, 9= Exit SP, 12=exit MP, 
		
	if state==3 and state2==5 and state3==1 then	
		Model2_SetWideScreen(0)
	else
		Model2_SetWideScreen(1)
	end

end

function timecheatfunc(value)
	I960_WriteWord(RAMBASE+AEB8,60);	--50 seconds always
end


function PostDraw()
-- This is test video draw code to show stuff on the screen -----------------------------------------------
--Video_DrawText(20,10,VRView,0xFFFFFF) -- VR View DrawFunction (Shows VR View selected in top left corner) 
--Video_DrawText(20,25,HEX16(I960_ReadDWord(RAMBASE+0x5198)),0xFFFFFF); -- Draw Speed on screen in HEX
--os.execute [["C:/Hyperspin/Emulators/m2emulator/VR Select.ahk" -windowhide]] 
-----------------------------------------------------------------------------------------------------------


				if M2Eouttimer >= 1
				then
					M2Eouttimer = M2Eouttimer - 1
				else
					Timeleft = (I960_ReadDWord(RAMBASE+0x10D0))	-- Reads Timeleft 
					VRView = I960_ReadWord(0x2140C0)    		-- Reads VRView from VR View in M2EMU RAM
					Position = I960_ReadWord(0x20AB40)		-- Reads "Race Position" value
					Gear = I960_ReadWord(0x500078)			-- Reads Gear selected Auto/Manual
					RPM = "000"				-- Reads RPM in HEX Double word
					KPH = "000"				-- Reads KPH in HEX Double word
					Gamestate1 = I960_ReadByte(0x202098)		-- Reads the gamestate1 of the emulator 
					Gamestate2 = I960_ReadByte(0x20209C)		-- Reads the gamestate2 of the emulator 
					Gamestate3 = I960_ReadByte(0x2020AC)		-- Reads the gamestate3 of the emulator
					local file = io.open('SegaRally_outputs.txt', "w")
					file:write(Gamestate1,",",Gamestate2,",",Gamestate3,",",VRView,",",Gear,",",KPH,",",RPM,",",Position,",",Timeleft)
					file:close()
					M2Eouttimer = 10 -- Outputs data every 10 frames
				end
				end

Options =
{
--	cheat1={name="Cheat 1",values={"Off","On"},runfunc=cheat1func,changefunc=cheat1change},
	timecheat={name="Infinite Time",values={"Off","On"},runfunc=timecheatfunc}
}