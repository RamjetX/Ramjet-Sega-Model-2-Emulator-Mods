require("model2");	-- Import model2 machine globals

function Init()
M2Eouttimer = 30
end

function Frame()
	Model2_SetWideScreen(1)
	Model2_SetStretchALow(1)
	Model2_SetStretchBLow(1)
	Model2_SetStretchAHigh(1)
	Model2_SetStretchBHigh(1)
end
	
--function Frame()
--	local gameState = I960_ReadByte(0x5010A4)
--
--	if   gameState==0x16	-- Ingame 				(22 in Decimal)
--	  or gameState==0x03	-- Attract ini			(03 in Decimal)
--	  or gameState==0x04	-- Attract Higscore ini (04 in Decimal)
--	  or gameState==0x05	-- Attract Highscore	(07 in Decimal)
--	  or gameState==0x06	-- Attract VR Ini		(06 in Decimal)
--	  or gameState==0x07	-- Attract VR			(07 in Decimal)
--	then
--	 	Model2_SetStretchBLow(1)	-- Stretch the bg tilemap (sky & clouds) when widescreen
--		Model2_SetWideScreen(1)
--	else					-- No widescreen on the rest of the screens
--	 	Model2_SetStretchBLow(0)
--		Model2_SetWideScreen(0)
--	end
--
--end

--Some sample code follows to show how to draw strings and setup options/cheats
--
--function PostDraw()
--	Video_DrawText(20,10,HEX32(I960_GetRamPtr(RAMBASE)),0xFFFFFF);
--	Video_DrawText(20,10,HEX32(I960_ReadWord(RAMBASE+0x10D0)),0xFFFFFF);
--	Video_DrawText(20,20,HEX32(RAMBASE),0xFFFFFF);
--	Video_DrawText(20,30,Options.cheat1.value,0xFFFFFF);
--	Video_DrawText(20,40,Input_IsKeyPressed(0x1E),0xFFFFFF);
--end
--
--function cheat1func(value)
--	
--end
--
--function cheat1change(value)
--
--end

function PostDraw()
-- This is test video draw code to show stuff on the screen -----------------------------------------------
--Video_DrawText(20,10,VRView,0xFFFFFF) -- VR View DrawFunction (Shows VR View selected in top left corner) 
--Video_DrawText(20,25,HEX16(I960_ReadDWord(RAMBASE+0x5198)),0xFFFFFF); -- Draw Speed on screen in HEX
--os.execute [["C:/Hyperspin/Emulators/m2emulator/VR Select.ahk" -windowhide]] 
-----------------------------------------------------------------------------------------------------------


				if M2Eouttimer >= 1
				then
					M2Eouttimer = M2Eouttimer - 1
				else
					Gamestate1 = (I960_ReadDWord(0x54C224))		-- 2 = Game track select modes/transmission, 
											-- 3 = Main logo
											-- 4 = Attact demo
											-- 5 = Ladies and Gentlemen
											-- 6 = Rolling Start (Very quick, not for whole rolling sequence)
											-- 7 = Inrace
											-- 8 = Gameover
					
					Gamestate2 = (I960_ReadDWord(0x54C228))		-- Reads 5 = Player Game, 3 = Attract/Demo
					Gamestate3 = (I960_ReadDWord(0x554AD4))		-- Reads 53 = Highscore list (use with attract mode)

					Timeleft = (I960_ReadDWord(0x554874))		-- Reads Timeleft 
					VRView = (I960_ReadWord(0x5569F4))    		-- Reads VRView from VR View in M2EMU RAM
					Position = (I960_ReadWord(0x554CB0))		-- Reads "Cars in front" value
					Gear = (I960_ReadWord(0x54C4A4))		-- Reads Gear selected Auto/Manual
					RPM = (I960_ReadDWord(0x54C604))		-- Reads RPM in HEX Double word
					MPH = 0 					-- math.floor,0x54C5E4
					--MPH = (I960_ReadDWord(0x54C5E4))		-- Reads MPH in HEX Double word
					-- No known Gamestates yet... 
					local file = io.open('indy500d_outputs.txt', "w")
					file:write(Gamestate1,",",Gamestate2,",",Gamestate3,",",VRView,",",Gear,",",MPH,",",RPM,",",Position,",",Timeleft)
					file:close()
					M2Eouttimer = 10 -- Outputs data every 10 frames
				end
				end
				
				
function timecheatfunc(value)
	I960_WriteWord(0x554874,99*64); -- 99 seconds always
end

function freezetimefunc(value)
	I960_WriteWord(RAM2BASE+0x22CE,1*64); -- freeze time
	I960_WriteWord(RAM2BASE+0x22D2,1*64); -- screen display
end

function firstplacefunc(value)
	I960_WriteWord(RAM2BASE+0x2308,0); -- competitors in front
end

Options =
{
	timecheat={name="Infinite Time Left",values={"Off","On"},runfunc=timecheatfunc},
	freezetime={name="Freeze Lap Time",values={"Off","On"},runfunc=freezetimefunc},
	firstplace={name="First Place",values={"Off","On"},runfunc=firstplacefunc}
}
