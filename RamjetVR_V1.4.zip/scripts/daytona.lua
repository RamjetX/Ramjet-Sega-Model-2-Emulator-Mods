require("model2");	-- Import model2 machine globals

function Init()
M2Eouttimer = 30
end


function Frame()
	local gameState = I960_ReadByte(0x5010A4)

	if   gameState==0x16	-- Ingame 				(22 in Decimal)
	  or gameState==0x03	-- Attract ini				(03 in Decimal)
	  or gameState==0x04	-- Attract Higscore ini 		(04 in Decimal)
	  or gameState==0x05	-- Attract Highscore			(05 in Decimal)
	  or gameState==0x06	-- Attract VR Ini			(06 in Decimal)
	  or gameState==0x07	-- Attract VR				(07 in Decimal)
	then
	 	Model2_SetStretchBLow(1)	-- Stretch the bg tilemap (sky & clouds) when widescreen
		Model2_SetWideScreen(1)
	else					-- No widescreen on the rest of the screens
	 	Model2_SetStretchBLow(0)
		Model2_SetWideScreen(0)
	end

end

--Some sample code follows to show how to draw strings and setup options/cheats
--
--function PostDraw()
--	Video_DrawText(20,10,HEX32(I960_GetRamPtr(RAMBASE)),0xFFFFFF);
--	Video_DrawText(20,10,HEX32(I960_ReadWord(RAMBASE+0x10D0)),0xFFFFFF);
--	Video_DrawText(20,20,HEX32(RAMBASE),0xFFFFFF);
--	Video_DrawText(20,30,Options.cheat1.value,0xFFFFFF);
--	Video_DrawText(20,40,Input_IsKeyPressed(0x1E),0xFFFFFF);
--end
--
--function cheat1func(value)
--	
--end
--
--function cheat1change(value)
--
--end

function PostDraw()
-- This is test video draw code to show stuff on the screen -----------------------------------------------
--Video_DrawText(20,10,VRView,0xFFFFFF) -- VR View DrawFunction (Shows VR View selected in top left corner) 
--Video_DrawText(20,25,HEX16(I960_ReadDWord(RAMBASE+0x5198)),0xFFFFFF); -- Draw Speed on screen in HEX
--os.execute [["C:/Hyperspin/Emulators/m2emulator/VR Select.ahk" -windowhide]] 
-----------------------------------------------------------------------------------------------------------


				if M2Eouttimer >= 1
				then
					M2Eouttimer = M2Eouttimer - 1
				else
					Timeleft = (I960_ReadDWord(RAMBASE+0x10D0))	-- Reads Timeleft 
					VRView = (I960_ReadWord(RAMBASE+0x1710))    	-- Reads VRView from VR View in M2EMU RAM
					Position = (I960_ReadWord(RAMBASE+0x51EC))	-- Reads "Cars in front" value
					Gear = (I960_ReadWord(RAMBASE+0x52CC))		-- Reads Gear selected Auto/Manual
					RPM = (I960_ReadDWord(RAMBASE+0x52D8))		-- Reads RPM in HEX Double word
					KPH = (I960_ReadDWord(RAMBASE+0x5198))		-- Reads KPH in HEX Double word
					Gamestate = (I960_ReadByte(0x5010A4))		-- Reads the gamestate of the emulator into a global Gamestate variable
					MPPosition = (I960_ReadByte(0x5051ED))		-- Reads the player position in a MP game (available on both Master and Slaves) 
					NumPlayers = (I960_ReadByte(0x501475))		-- Reads the number of players in the game... 1 = Single player only, 0 = Probably hosted by different machine or 2+ if hosting and mutliplayer
					local file = io.open('daytona_outputs.txt', "w")
					file:write(Gamestate,",",VRView,",",Gear,",",KPH,",",RPM,",",Position,",",Timeleft,",",MPPosition,",",NumPlayers)
					file:close()
					M2Eouttimer = 10 -- Outputs data every 10 frames
				end
				end
			

				

function timecheatfunc(value)
	I960_WriteWord(RAMBASE+0x10D0,50*64);	--50 seconds always
end

Options =
{
--	cheat1={name="Cheat 1",values={"Off","On"},runfunc=cheat1func,changefunc=cheat1change},
	timecheat={name="Infinite Time",values={"Off","On"},runfunc=timecheatfunc}
}
