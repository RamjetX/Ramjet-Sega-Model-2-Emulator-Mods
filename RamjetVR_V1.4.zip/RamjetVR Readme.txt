Welcome to the RamjetVR output emulator support for Sega Model 2 Emulator.
--------------------------------------------------------------------------

- RamjetVR Version 1.4 - 

This is a readme file on how to use this software

Games (ROMS) supported
----------------------

Daytona USA (daytona.zip)
Sega Touring Car Championship (stcc.zip)
Indy 500 Deluxe (indy500d)
Sega Rally Championship (srallyc.zip)

I have only included support for the 4 major games I have intended to run on my own arcade project. If there are other requests for future support for other
games, please visit my youtube channel and contact with me there.

(Make sure your running the correct ROM for this program to work)

-----------------------------------
http://www.youtube.com/user/ramjetr
-----------------------------------


Contents of RamjetVR V1.4.zip
------------------------------

RamjetVR_V1.4.exe	- Main Program and Gui. This is written with AutoHotKey scripting language.
RamjetVR_Settings.ini	- Where settings are saved when you click apply, also it is read on start up of the program. If it's missing, just enter something into the boxes and hit apply to create it.
VRPanel.jpg		- The image used for the program background (10 points if you can guess who's machine I ripped the image from! :P )
PacDrive.dll		- The PacDrive.dll file which is used to control the PacDrive connected to your PC 
\Scripts		- Replacement lua scripts for the model 2 emulator to generate the output data needed.
	\daytona.lua
	\stcc.lua
	\indy500d.lua
	\srallyc.lua

Installation
------------

Extract the contents of this zip file into the root folder of your model2 emulator.

It should overwrite your lua scripts in your scripts folder. If your running any custom scripts, these WILL be overwritten! It won't effect alot of people (unless 
your running custom scripts for cheats?), but I do have mine set for 16:9 Widescreen (This is default). Adjust these scripts for your preference for widescreen or 
normal. 


What do I run?
--------------

So you've copied the above files into the same folder as your model 2 emulator? and the scripts are in the \scripts folder as they should be?

Yes... ok then... just double click RamjetVR_1.4.exe and it will run... If you don't have a PacDrive connected, it will tell you, but this time let you continue to 
see the main window.

By default, my personal settings are there. Just enter the number of the port on the PCB of the pacdrive that you've wired to your VR LED's. 

Keep the program running in the background to keep the LED's being updated. I will add auto launching of RamjetVR into the scripts for the next release once I check
that it won't interfere with foreground/background focus etc...


What will this program do?
--------------------------

OK, here's the very quick version of what this program does... The LUA scripts used by the Sega Model 2 Emulator will read in game memory locations used by the 
emulator running the rom in real time. It extracts things like speed, gears, timeleft, position, vrview etc and output the data in a txt file in the main m2emulator
folder. Why doesn't it just output stuff like the actual Light output information? Simple, because the IO board of light outputs don't appear to be emulated by the 
model 2 emulator, or if they are, there is nowhere for me to find the live output calls to the IO board. 

So, I've written this program (RamjetVR_V1.4.exe) to make sense of the RAM of the game as its running and recreate the outputs. It reads the *rom*_outputs.txt file 
every 20ms and sets the PacDrive outputs according to which game is running.

The outputs will be off when no game is running.

The number of times per second that file is written to is dependent on your frames per second you can generate. By default, it will update that txt file every 
10 frames. You can adjust this yourself to tune for faster or slower update rates. The main difference is going to be writes to a HDD. Windows 7 and 8 is better 
than WinXP for delaying actually committing that file to disk meaning it will write it, but not actually to the drive since it's always being updated. I don't know
the long term effect of doing this to Solid State HDD's. But since there is a paranoia about reducing writes on a SSD I thought I'd mention how many times it writes
to the disk per second for your own reference.

On an interesting side note, I personally run a RamDisk and launch the program from inside a virtual hard drive in RAM. It's super fast and doesn't write to your SSD at all!!!

Changelog;

   Updated By Mark 'Ramjet' Gallon 15/6/2012
   Added support for Indianapolis 500 (Rev A,Deluxe) - indy500d rom
   Found and configured gamestates for future lighting sequencing

   Updated By Mark 'Ramjet' Gallon 25/5/2012
   Added support for Sega Touring Car Championship   - stcc    rom


   Updated By Mark 'Ramjet' Gallon 17/5/2012
   Added support for Sega Rally Championship	- srallyc rom
   Code optimised for auto game detection and switching


   Coded By Mark 'Ramjet' Gallon 28/01/2012
   Initial coding for proof of concept.
   Daytona Supported		- daytona rom
   Settings and Gui coded optimised
   Importer coded
   Heavily optimised sequencer


Whats left to do;

Well as you will notice, some of the advanced attraction Leader lamp flashing sequences need to be coded. But that requires sitting down and watching a machine, where it flashes 
and when. For the most part, it looks fine as it is. But I'll be researching into the code more to see if I can extract the authentic attract sequences.

Known bug
---------

It will sometimes detect windows with the same title as the game as being a game running. ie watch a youtube video of "daytona usa" and internet explorer changes its
title to that name and tricks my program into thinking it's running and begins lighting up led's. Took me ages to figure out why it was doing that! Turned out I was 
watching a youtube video whilst writing the code. Anyway, it's a feature... not a fault :) And not a bloody thing I can do to stop it... 


