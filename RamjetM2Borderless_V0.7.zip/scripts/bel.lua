require("model2");	-- Import model2 machine globals

function Init()
os.execute [["RamjetM2Borderless.exe"]]
end

function Frame()
--	Model2_SetWideScreen(1)
--	Model2_SetStretchALow(1)
--	Model2_SetStretchBLow(1)
--	Model2_SetStretchAHigh(1)
--	Model2_SetStretchBHigh(1)
end
	
--function Frame()

--end


--Some sample code follows to show how to draw strings and setup options/cheats
--
--function PostDraw()
--	Video_DrawText(20,10,HEX32(I960_GetRamPtr(RAMBASE)),0xFFFFFF);
--	Video_DrawText(20,10,HEX32(I960_ReadWord(RAMBASE+0x10D0)),0xFFFFFF);
--	Video_DrawText(20,20,HEX32(RAMBASE),0xFFFFFF);
--	Video_DrawText(20,30,Options.cheat1.value,0xFFFFFF);
--	Video_DrawText(20,40,Input_IsKeyPressed(0x1E),0xFFFFFF);
--end
--
--function cheat1func(value)
--	
--end
--
--function cheat1change(value)
--
--end

function PostDraw()
-- This is test video draw code to show stuff on the screen -----------------------------------------------

-----------------------------------------------------------------------------------------------------------
end
				

