Welcome to the - RamjetM2Borderless V0.7 -  support for Sega Model 2 Emulator.
--------------------------------------------------------------------------

This is a readme file on how to use this software

This program will enable users to run their favourite lightgun shooters on Nebula's Model 2 Emulator and off screen reload without the program Alt-Tabbing or
accidently minimizing to desktop.

Games (ROMS) supported
----------------------

Virtua Cop 1
Virtua Cop 2
House of the Dead
Rail Chase 2
Gunblade NY
Behind Enemy Lines



My Youtube Channel - please visit my youtube channel and make contact with me there.
-----------------------------------
http://www.youtube.com/user/ramjetr
-----------------------------------

or visit the active forum where this is currently being discussed

--------------------------------------------------------
http://forum.arcadecontrols.com/index.php?topic=104484.0
--------------------------------------------------------

Sega Model 2 Emulator can be found here

------------------------------
http://nebula.emulatronia.com/
------------------------------

---------------------------------------
Contents of RamjetM2Borderless V0.7.zip
---------------------------------------

RamjetM2Borderless.exe 	- The main program that monitors and sets borderless only the active Model 2 Emulator games below. Version number is removed for ease of LUA launching
gunbladeNY.ico 		- The following icons are loaded into the task bar when the game has been detected and running.
HOTD.ico
RailChase2.ico
Sega2.ico
VCop1.ico
behindenemylines.ico
\Scripts		- LUA scripts to be ran by the Model2Emulator, This will automatically launch the RamjetM2Borderless program for you when the game is launched.
	bel.lua
	vcop.lua
	vcop2.lua
	hotd.lua
	rchase2.lua
	gunblade.lua




Installation
------------

Extract the contents of this zip file into the root folder of your model2 emulator.


What do I run? and What will this program do?
---------------------------------------------

*** Updated ***

In this release there is a slight change for the usage of this program since.

Now included in the Zip file is a \Scripts folder with LUA scripts which will be auto executed by M2 Emulator when the ROM is launched. Within the script, it calls a command window
and launches the RamjetM2Borderless.exe to run in background. Unfortunately the M2 Emulator LUA script cannot hide the cmd window, however it will only appear very briefly as the
RamjetM2Bordlerless program will actively close the cmd window for you in the background once it's executed.

When running with a Front End, hopefully you won't see any of this happening behind the scene. Depending on how the Front End handles the blanking of the screen between launching and 
showing the emulator, your milage may vary.

You'll see a new little White/Blue Sega icon appear in your task bar next to the clock. This will change icon depending on which game is detected to be running

It will constantly scan for a one of the above games to run and then force the active title bar matching that name to run without a border. This will remove
the Min,Max,X buttons from the active window. Once running it will kill the cmd window that was opened by M2 Emulator and minimize.

This app will now auto close when Model2Emulator is closed. Since it's being launched directly by the Model 2 emulator via the LUA scripts, there is no need to manually start this 
program.


Changelog;

	V0.7	- Updated by Mark 'Ramjet' Gallon 11/7/2012
		  Found solution to not autoclosing in WinXP in this forum thread. Many Thanks go to 'Serenity' for sharing his/her solution. 
		  http://www.autohotkey.com/community/viewtopic.php?t=35438
		  Program should now actively close the M2Emulator cmd window in all Windows OS correctly now :)

	V0.6	- Updated by Mark 'Ramjet' Gallon 10/7/2012
		  Changed how RamjetM2Borderless detects and close's the M2emulator cmd window that is opened when the game ROM launches it. Previously used a Postmessage to close a 
		  particular cmd window (which was kinda cool and tricky), but may have had problems on WinXP? Took it back to basics and used WinWait to check for the cmd window and 
		  WinClose to close down the cmd window. Worked on my WinXP and Win7 machines. Visit the forum above to comment and give feedback.
 
	V0.5	- Updated by Mark 'Ramjet' Gallon 6/7/2012
		  Added LUA scripts to Autolaunch RamjetM2Borderless for all shooting games.
		  Automated the cmd window closure from M2 Emulators LUA script which launched this program automatically.
		  Automated the exit of this app when M2 Emulator is no longer running.
		  Added right-click to the taskbar icons for an Exit and About information.
		  General clean up of old test code which had become distracting.
		  		  		  

	V0.4	- Updated by Mark 'Ramjet' Gallon 3/7/2012
		  Added support for Behind Enemy Lines with icon in tasktray
	
	V0.3	- Updated By Mark 'Ramjet' Gallon 1/7/2012
		  Since I didn't do a ReadMe for the first test program... here is the total changelog
		  Code and test borderless concept - Working!
		  Added more game support (see top of txt) with auto detection
		  Created Icons for the task bar on game detect (for fun)
		  Wrote this ReadMe.txt
	

Whats left to do;

Maximise/Window Detection to work correctly... I'll explain, I'm trying to detect when the game is full screen to remove border's and reapply them when back in a window mode
But it appears that the Model 2 Emulator doesn't set this flag correctly and hence it won't detect the transition from window to fullscreen. Working on that.... For now it 
will remove the borders from the window with the active title bar that matches the name of the game and keeps them gone for as long as the progam is running. 

Working on making sure that the correct window has it's borders removed... if you accidently remove the border from something (see bug below) alt-f4 and re-open it.

Known bug
---------

**** Update : The bug below may only occur if you've manually launched the program and it's running whilst your doing other things with your PC. If the program is launched by 
M2Emulator as it should be with the scripts, then the active window should only be the emulator and exited automatically. The occurance of the below mentioned bug should be all
but practically eliminated. **** 

It will sometimes detect a window with the same title as the game as being the game running. ie watch a youtube video of "Virtua Cop" and internet explorer changes its
title to that name and tricks my program into thinking it's running and removes the title bar. Took me ages to figure out why it was doing that! Turned out I was 
watching a youtube video whilst writing the code. Anyway, it's a feature... not a fault :) And not a bloody thing I can do to stop it... and it should restore itself when the 
program is Alt-F4'd (windows shortcut for close) and restarted. Don't panic, it's not the end of the world.


Thanks
------

Big Thanks go out to elsemi and all who've worked so hard to bring Model 2 Memories to the home. The Model 2 Emulator is the inspiration to all of us to create and develope and
restore the fond memories of a gaming era past. 

Thankyou!

Ramjet :D

